# Sistema-Registro-Login-em-Textdraw
 
Este e um sistema de registro, login e genero criado em textdraw para plataforma Android e Computador.

# Salvamento

- Senha
- Dinheiro
- Level
- Skin
- Genero
- Admin
- Interior
- Virtual World
- Vida
- Colete
- Pos X, Y, Z, R.

# Pastas
``Contas``

# Includes
- DOF2

# Fotos
![Foto_1](https://user-images.githubusercontent.com/78665880/150892760-d7af8fa8-8858-412b-bac6-25b1676524a1.jpg)
![Foto_2](https://user-images.githubusercontent.com/78665880/150892775-3279c594-d701-4681-a6f0-6f34a9bc7e47.jpg)
